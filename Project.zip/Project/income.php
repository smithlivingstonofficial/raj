<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
    redirect('index.php');
}

$user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
$uid = $usid['id'];
include ('header.php');
?>

<div class="mainpanel">
    <div class="contentpanel">
        <div class="container">
            <h1 class="page-header">Income Management</h1>
            <div class="btn-group">
                <a href="incadd.php" class="btn btn-primary btn-lg" style="margin-right: 10px; background-color: #5cb85c; border-color: #4cae4c;">
                    <i class="fa fa-plus"></i> Add Income
                </a>
                <a href="incview.php" class="btn btn-primary btn-lg" style="background-color: #337ab7; border-color: #2e6da4;">
                    <i class="fa fa-list"></i> View/Edit Income
                </a>
                <a href="inccatadd.php" class="btn btn-primary btn-lg" style="background-color: #d9534f; border-color: #d43f3a;">
                    <i class="fa fa-plus"></i> Add Income Category
                </a>
                <a href="inccatview.php" class="btn btn-primary btn-lg" style="background-color: #5bc0de; border-color: #46b8da;">
                    <i class="fa fa-list"></i> View/Edit Income Category
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
