<?php
require_once('function.php');
dbconnect();
session_start();

if (!is_user()) {
	redirect('index.php');
}

?>

		

<?php
 $user = $_SESSION['username'];
$usid = $pdo->query("SELECT id FROM users WHERE username='".$user."'");
$usid = $usid->fetch(PDO::FETCH_ASSOC);
 $uid = $usid['id'];
 include ('header.php');
 ?>
<link rel="stylesheet" type="text/css" href="css/form-styles.css">



 
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add Customer</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                
                <div class="col-md-10 col-md-offset-1">
				
				
	

		<?php

if($_POST)
{

$fullname = $_POST["fullname"];
$address = $_POST["address"];
$phonenumber = $_POST["phonenumber"];
$sex = $_POST["sex"];
$email = $_POST["email"];
$city = $_POST["city"];
$comment = $_POST["comment"];

$res = $pdo->exec("INSERT INTO customer SET fullname='".$fullname."', address='".$address."', phonenumber='".$phonenumber."', sex='".$sex."',`email`='".$email."',`city`='".$city."',`comment`='".$comment."'");
$cid = $pdo->lastInsertId();
if($res){

echo "<div class='alert alert-success alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>	

Customer Added Successfully!

</div>
<meta http-equiv='refresh' content='2; url=addmeasurement.php?id=$cid' /> 
";


}



} 
	?>
		


	 <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script>		
				
				
				
				
				
				    <form action="customeradd.php" method="post">
		
                    
                <div class="form-group">
                    <label>Full Name</label>
                    <div class="col-3 input-effect">
                        <input class="effect-20" type="text" name="fullname" placeholder="">
                        <label>Full Name</label>
                        <span class="focus-border">
                            <i></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Address</label>
                    <div class="col-3 input-effect">
                        <input class="effect-20" type="text" name="address" placeholder="">
                        <label>Address</label>
                        <span class="focus-border">
                            <i></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Phone Number</label>
                    <div class="col-3 input-effect">
                        <input class="effect-20" type="text" name="phonenumber" placeholder="">
                        <label>Phone Number</label>
                        <span class="focus-border">
                            <i></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label>City</label>
                    <div class="col-3 input-effect">
                        <input class="effect-20" type="text" name="city" placeholder="">
                        <label>City</label>
                        <span class="focus-border">
                            <i></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <div class="col-3 input-effect">
                        <input class="effect-20" type="text" name="email" placeholder="">
                        <label>Email</label>
                        <span class="focus-border">
                            <i></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Comment</label>
                    <div class="col-3 input-effect">
                        <textarea class="effect-20" rows="4" cols="50" name="comment" placeholder=""></textarea>
                        <label>Comment</label>
                        <span class="focus-border">
                            <i></i>
                        </span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Sex</label>
                    <select name="sex" class="form-control">
                        <option value="1">Female</option>
                    </select><br/><br/>
                </div>

                <input type="submit" class="btn btn-lg btn-success btn-block" value="ADD">
            </form>
                </div>
						
						
						
						
						
				
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
	    



<script src="js/bootstrap-timepicker.min.js"></script>


<script>
jQuery(document).ready(function(){
    
  
  jQuery("#ssn").mask("999-99-9999");
  
  // Time Picker
  jQuery('#timepicker').timepicker({defaultTIme: false});
  jQuery('#timepicker2').timepicker({showMeridian: false});
  jQuery('#timepicker3').timepicker({minuteStep: 15});

  
});
</script>







<?php
 include ('footer.php');
 ?>